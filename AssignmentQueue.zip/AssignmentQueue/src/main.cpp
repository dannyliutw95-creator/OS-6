/**
 * OS-6 延伸題: AssignmentQueue by 8 LEDs
 * 實作 FreeRTOS Queue 傳遞隨機值並控制 8 顆 LED
 */

#include "pico/stdlib.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"  // 務必引入 Queue 功能
#include <stdio.h>
#include <stdlib.h>

#include "BlinkAgent.h"
#include "CounterAgent.h"

// 任務優先級
#define TASK_PRIORITY       ( tskIDLE_PRIORITY + 1UL )

// LED 腳位定義 (依序使用 GPIO 2 到 9)
#define BLUE_LED_PAD  0
#define LED0_PAD      2
#define LED1_PAD      3
#define LED2_PAD      4
#define LED3_PAD      5
#define LED4_PAD      6
#define LED5_PAD      7
#define LED6_PAD      8
#define LED7_PAD      9

// 宣告 Queue 控制句柄
QueueHandle_t xAssignmentQueue;

// ---------------------------------------------------------
// 保留你原本的 runTimeStats 函數 (略，請放在此處)
// ---------------------------------------------------------

/**
 * 顯示任務 (Consumer): 從 Queue 接收數值並顯示在 8 顆 LED 上
 */
void displayTask(void *params){
    // 注意：需確保你的 CounterAgent 建構子支援 8 個腳位
    // 如果 CounterAgent 只能傳 4 個，請修改 CounterAgent.cpp 或在此手動初始化 GPIO
    CounterAgent counter(LED0_PAD, LED1_PAD, LED2_PAD, LED3_PAD, 
                         LED4_PAD, LED5_PAD, LED6_PAD, LED7_PAD);
    
    uint8_t receivedVal;

    printf("Display Task started\n");
    counter.start("Counter", TASK_PRIORITY);

    while (true) {
        // 從 Queue 讀取資料，直到有資料才繼續執行 (portMAX_DELAY)
        if (xQueueReceive(xAssignmentQueue, &receivedVal, portMAX_DELAY) == pdPASS) {
            counter.blink(receivedVal); 
            printf("LED Display updated to: 0x%02X\n", receivedVal);
        }
    }
}

/**
 * 主任務 (Producer): 負責產生隨機數並透過 Queue 發送
 */
void mainTask(void *params){
    BlinkAgent blink(BLUE_LED_PAD);
    blink.start("Blink", TASK_PRIORITY);

    printf("Main (Producer) Task started\n");

    while (true) {
        // 執行狀態回報
        runTimeStats();

        // 產生 8-bit 隨機數 (0x00 ~ 0xFF)
        uint8_t r = rand() & 0xFF;
        
        // 將隨機數發送到 Queue
        if (xQueueSend(xAssignmentQueue, &r, 10) != pdPASS) {
            printf("Queue is full!\n");
        } else {
            printf("Sent to Queue: 0x%02X\n", r);
        }

        vTaskDelay(pdMS_TO_TICKS(3000)); // 延遲 3 秒
    }
}

/**
 * 啟動任務與佇列
 */
void vLaunch(void) {
    // 1. 建立 Queue (長度 5, 每個元素大小為 uint8_t)
    xAssignmentQueue = xQueueCreate(5, sizeof(uint8_t));

    if (xAssignmentQueue != NULL) {
        // 2. 建立 Producer 任務
        xTaskCreate(mainTask, "MainThread", 512, NULL, TASK_PRIORITY, NULL);
        
        // 3. 建立 Consumer 任務 (負責處理 Queue 資料並亮燈)
        xTaskCreate(displayTask, "DisplayThread", 512, NULL, TASK_PRIORITY, NULL);

        /* 啟動排程器 */
        vTaskStartScheduler();
    } else {
        printf("Failed to create Queue!\n");
    }
}

int main(void)
{
    stdio_init_all();
    sleep_ms(2000);
    printf("Starting AssignmentQueue with 8 LEDs...\n");

    vLaunch();

    return 0;
}